using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthHappyController : MonoBehaviour
{
    //public int curHealth = 0;
    //public int maxHealth = 100;

    [SerializeField] private Slider sliderHealth, sliderHappy;
    [SerializeField] private int distance = 50;
    [SerializeField] private GameObject companion;
    private Animator anim;

    /*void Start()
    {
        curHealth = maxHealth;
    }

    void Update()
    {
        if( Input.GetKeyDown( KeyCode.Space ) )
        {
            DamagePlayer(10);
        }
    }

    public void DamagePlayer( int damage )
    {
        curHealth -= damage;

        sliderHealth.SetHealth( curHealth );
    }*/


    // Start is called before the first frame update
    void Start()
    {
        //sliderHealth = GetComponent<Slider>();
        //sliderHappy = GetComponent<Slider>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {

        if (sliderHealth.value == 0) {
            anim.SetTrigger("death");
        }
        if (sliderHappy.value == 0) {
            sliderHealth.value--;
        }
        if (Vector3.Distance(companion.transform.position, transform.position) > distance)
        {
            if (sliderHappy.value > 0)
            {
                sliderHappy.value--;
            }
        }
        if (Vector3.Distance(companion.transform.position, transform.position) < distance)
        {
            if (sliderHappy.value < 1000)
            {
                sliderHappy.value++;
            }
        }
        if ((sliderHappy.value == 1000) && (sliderHealth.value < 1000)) {
            sliderHealth.value++;
        }

    }


}
