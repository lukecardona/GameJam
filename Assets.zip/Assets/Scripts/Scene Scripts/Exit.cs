using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exit : MonoBehaviour
{
    // Exits the game
    public void QuitGame()
    {
       Application.Quit();
        Debug.Log("Goodbye"); 
    }
}
